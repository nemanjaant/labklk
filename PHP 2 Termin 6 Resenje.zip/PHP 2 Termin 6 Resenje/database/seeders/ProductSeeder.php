<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Illuminate\Support\Arr;
use Faker\Factory as Faker;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
	 
	private $currencies = ['RSD', 'EUR'];
    
    public function run()
    {
        $faker = Faker::create();
        for($i = 1; $i <= 15; $i++) {
            $id = \DB::table('products')->insertGetId([
                'name' => $faker->word,
                'price' => rand(5, 50),
				'currency' => $this->currencies[rand(0,1)],
                'image' => 'product'.$i.'.jpg',
                'supplier_id' => rand(1,5),
                'description' => $faker->paragraph
            ]);

			for($j = 0; $j < rand(1,3); $j++){
				\DB::table('category_product')->updateOrInsert([
					'product_id' => $id,
					'category_id' => rand(1,5)
				]);
			}
        }
    }
}

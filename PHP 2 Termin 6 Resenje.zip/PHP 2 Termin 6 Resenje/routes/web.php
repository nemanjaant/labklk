<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CategorySupplierController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ProductController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [HomeController::class, 'index'])->name('home');

Route::get('/products', [ProductController::class, 'index'])->name('products');

Route::middleware(['auth', 'admin'])->group(function() {
    Route::get('/products/create', [ProductController::class, 'create'])->name('products.create');
    Route::post('/products/store', [ProductController::class, 'store'])->name('products.store');

    Route::get('/admin/products', [ProductController::class, 'getAll'])->name('admin.products');
    Route::delete('/admin/products/{id}', [ProductController::class, 'delete'])->name('product.delete');

    Route::get('/admin/category-supplier', [CategorySupplierController::class, 'getCategoriesSuppliers'])->name('category-supplier');
    Route::post('/admin/category-supplier', [CategorySupplierController::class, 'insertCategoriesSuppliers'])->name('category-supplier-insert');
    Route::delete('/admin/category/{id}', [CategorySupplierController::class, 'deleteCategories'])->name('category-delete');
    Route::delete('/admin/supplier/{id}', [CategorySupplierController::class, 'deleteSuppliers'])->name('supplier-delete');
    
    Route::get('/admin/users', [AuthController::class, 'showUsers'])->name('users');
    Route::match(['post', 'get'], '/admin/users/{id}', [AuthController::class, 'editUser'])->name('user.edit');
    Route::put('/admin/user/{id}', [AuthController::class, 'updateUser'])->name('user.update');
});

Route::get('/products/{id}', [ProductController::class, 'show'])->name('product');
Route::get('/all-products', [ProductController::class, 'getAll'])->name('all-products');

Route::get('/contact', [ContactController::class, 'index'])->name('contact');

Route::middleware(['notauth'])->group(function() {
    Route::get('/login', [AuthController::class, 'loginForm'])->name('loginForm');
    Route::post('/login', [AuthController::class, 'doLogin'])->name('login');
});

Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

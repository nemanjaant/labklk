<div class="col-lg-{{$largeSize}} col-md-{{$mediumSize}} mb-4">
    <div class="card h-100">
      <a href="{{$url}}"><img class="card-img-top" src="{{ asset('assets/img/' . $image) }}" alt="{{ $alt }}"></a>
      <div class="card-body">
        <h4 class="card-title">
          <a href="{{$url}}">{{ $title }}</a>
        </h4>
        <h5>{{ $subtitle }}</h5>
        @foreach ($categories as $ind => $c)
          <span>{{count($categories) - 1 == $ind ? $c->name : $c->name.', '}}</span>
        @endforeach
        @if(!empty($body))
        <p class="card-text mt-3">{{ $body }}</p>
        @endif
      </div>
    </div>
  </div>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  <div class="container">
    <a class="navbar-brand" href="#">
      <h1 class="h3">Shop</h1>
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav ml-auto">
        @foreach($menu as $link)
        <li class="nav-item @if(request()->routeIs($link->route)) active @endif">
          <a class="nav-link" href="{{ route($link->route) }}">{{ $link->name }}</a>
        </li>
        @endforeach
        @if(!Auth::check())
        <li class="nav-item">
          <a class="nav-link" href="{{ route('loginForm') }}">Log in</a>
        </li>
        @else
        <li class="nav-item">
          <form action="{{route('logout')}}" method="POST" id="logoutForm">
            @csrf
            <a class="nav-link" href="#" onclick="event.preventDefault(); document.getElementById('logoutForm').submit();">
              {{ Auth::user()->name }} (Log out)
            </a>
          </form>
        </li>
        @endif
      </ul>
    </div>
  </div>
  @if(Auth::check() && Auth::user()->role_id === 2)
  <ul class="navbar-nav ml-auto">
    <li class="nav-item"><a class="nav-link" href="{{route('admin.products')}}"> Products</a></li>
    <li class="nav-item"><a class="nav-link" href="{{route('category-supplier')}}"> Categories-Suppliers</a></li>
    <li class="nav-item"><a class="nav-link" href="{{route('users')}}">Users</a></li>
  </ul>
  @endif
</nav>
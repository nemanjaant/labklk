@extends('layouts.layout')

@section('title') Add product @endsection
@section('description') Add a product. @endsection
@section('keywords') shop, online, products @endsection

@section('content')
<div class="container mt-4 min-vh-100">
    @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
            
        </ul>
    </div>
    @endif

    @if (session('success-msg'))
    <div class="alert alert-success">
        <p>{{session('success-msg')}}</p>
    </div>
    @endif

    @if (session('error-msg'))
    <div class="alert alert-danger">
        <p>{{session('error-msg')}}</p>
    </div>
    @endif
     
    <form action="{{route('products.store')}}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="mb-3">
            <label for="name" class="form-label">Name</label>
            <input type="text" class="form-control" id="name" name="name" value="{{old('name')}}" />
        </div>
        <div class="mb-3">
            <label for="price" class="form-label">Price</label>
            <input type="text" class="form-control" id="price" name="price" value="{{old('price')}}" />
        </div>
		<div class="mb-3">
            <label for="currency" class="form-label">Currency</label>
            <select id="currency" class="form-control" name="currency">
				<option value="0">Choose...</option>
				<option value="RSD" @if(old('currency') == 'RSD') selected @endif>RSD</option>
				<option value="EUR" @if(old('currency') == 'EUR') selected @endif>EUR</option>
			</select>
        </div>
        <div class="mb-3">
            <label for="currency" class="form-label">Supplier</label>
            <select id="currency" class="form-control" name="currency">
				<option value="0">Choose...</option>
				@foreach ($suppliers as $supplier)
                    <option value="{{$supplier->id}}">{{$supplier->name}}</option>
                @endforeach
			</select>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea id="description" cols="30" rows="10" class="form-control" name="description">{{old('description')}}</textarea>
        </div>
		<div class="mb-3 row">
            <div class="col-md-2">
                <input type="radio" id="rb-active" value="1" name="active" @if(old('active') == 1) checked @endif />
                <label for="rb-active">Active</label>
            </div>
			<div class="col-md-2">
                <input type="radio" id="rb-inactive" value="0" name="active" @if(old('active') == 0) checked @endif />
                <label for="rb-inactive">Inactive</label>
            </div>
        </div>
        <div class="mb-3 row">
            @foreach($categories as $category)
            <div class="col-md-3">
                <input type="checkbox" id="cat-{{$category->id}}" value="{{$category->id}}" name="categories[]" 
                    @if(old('categories') && in_array($category->id, old('categories'))) checked @endif />
                <label for="cat-{{$category->id}}">{{$category->name}}</label>
            </div>
            @endforeach
        </div>
		<div class="mb-3">
            <label for="image" class="form-label">Image</label>
            <input type="file" id="image" name="image"/>
        </div>
        <div>
            <button type="submit" class="btn btn-primary">Add</button>
        </div>
    </form>
</div>
@endsection
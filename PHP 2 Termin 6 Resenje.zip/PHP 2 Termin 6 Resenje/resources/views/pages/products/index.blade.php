@extends('layouts.layout')

@section('title') Products @endsection
@section('description') Browse all of our products. @endsection
@section('keywords') shop, online, products @endsection

@section('content')
  <div class="container mt-4 min-vh-100">

    <div class="d-flex justify-content-between align-items-center">
      <h1>Products</h1>
      @if(Auth::check() && Auth::user()->role_id == 2)
        <a href="{{route('products.create')}}" class="btn btn-secondary">Add a product</a>
      @endif
    </div>
    <hr />

    <div class="row">

      <div class="col-lg-3">

        <ul class="list-group">
          @foreach($data["categories"] as $categories)
          <li class="list-group-item">
            <input type="checkbox" name="categories" id="{{ $categories->id }}" /> {{ $categories->name }}
          </li>
          @endforeach
        </ul>

      </div>
      <!-- /.col-lg-3 -->

      <div class="col-lg-9">

        <div class="row" id="products">
          
        </div>
        <!-- /.row -->

      </div>
      <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

    
    <!-- /.row -->

  </div>
@endsection

@section('scripts')
  <script>
    const baseUrl = "{{url('/')}}"
  </script>
  <script src="{{asset('assets/js/products.js')}}"></script>
@endsection
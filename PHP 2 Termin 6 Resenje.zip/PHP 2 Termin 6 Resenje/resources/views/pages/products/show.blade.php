@extends('layouts.layout')

@section('title') Products @endsection
@section('description') Browse all of our products. @endsection
@section('keywords') shop, online, products @endsection

@section('content')
<div class="container mt-4 min-vh-100">

    <x-card 
        :image="'products/' . $product->image" 
        :alt="$product->name"
        :title="$product->name"
        :subtitle="'$' . $product->price"
        :body="$product->description"
        largeSize="12"
        mediumSize="12" />

</div>
@endsection
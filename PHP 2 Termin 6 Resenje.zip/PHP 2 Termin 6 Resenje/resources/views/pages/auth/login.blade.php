@extends('layouts.layout')

@section('title') Login @endsection
@section('description') Log in into your account. @endsection
@section('keywords') shop, online, products @endsection

@section('content')
<div class="container mt-4 min-vh-100">

    @if (session('error-msg'))
    <div class="alert alert-danger">
        <p>{{session('error-msg')}}</p>
    </div>
    @endif
     
    <form action="{{route('login')}}" method="POST">
        @csrf
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" />
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" />
        </div>
        <div>
            <button type="submit" class="btn btn-primary">Login</button>
        </div>
    </form>
</div>
@endsection
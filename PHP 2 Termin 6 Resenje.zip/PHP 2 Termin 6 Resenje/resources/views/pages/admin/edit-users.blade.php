@extends('layouts.layout')

@section('title') Edit user @endsection
@section('description') Edit user @endsection
@section('keywords') User @endsection

@section('content')
<div class="container my-5">
    <h3 class="text-center">Edit user</h3>
    @if(Session::get('error'))
    <p class="alert alert-danger">{{Session::get('success')}}</p>
    @endif
    <form action="{{route('user.update', ['id' => $user->id])}}" method="post">
        @csrf
        @method('put')
        <div class="form-group">
            <label for="firstName">First Name</label>
            <input type="text" class="form-control" id="firstName" value="{{$user->first_name}}" name="firstName">
            @error('firstName')
                <p class="text-danger m-0">{{$message}}</p>
            @enderror
        </div>
        <div class="form-group">
            <label for="lastName">Last Name</label>
            <input type="text" class="form-control" id="lastName" value="{{$user->last_name}}" name="lastName">
            @error('lastName')
                <p class="text-danger m-0">{{$message}}</p>
            @enderror
        </div>
        <div class="form-group">
            <label for="email">Email address</label>
            <input type="email" class="form-control" id="email" value="{{$user->email}}" name="email">
            @error('email')
                <p class="text-danger m-0">{{$message}}</p>
            @enderror
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password" />
        </div>
        <div class="form-group">
            <label for="role">User role</label>
            <select class="form-control" id="role" name="role">
                @foreach ($roles as $r)
                <option value="{{$r->id}}" @if($user->role_id == $r->id) selected @endif>{{$r->role}}
                </option>
                @endforeach
            </select>
            @error('role')
                <p class="text-danger m-0">{{$message}}</p>
            @enderror
        </div>
        <button type="submit" class="btn btn-primary">Edit</button>
    </form>
</div>
@endsection
@extends('layouts.layout')

@section('title') Users - admin panel @endsection
@section('description') All users @endsection
@section('keywords') Users @endsection

@section('content')
<div class="container my-5">
    <h2 class="text-center my-5">Admin panel - Users</h2>
    @if(Session::get('success'))
        <p class="alert alert-success">{{Session::get('success')}}</p>
    @endif
    @if(Session::get('error'))
        <p class="alert alert-danger">{{Session::get('success')}}</p>
    @endif
    <table class="table">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">First Name</th>
                <th scope="col">Last Name</th>
                <th scope="col">Email</th>
                <th scope="col">Role</th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
            @foreach ($users as $user)
            <tr>
                <td>{{$user->id}}</td>
                <td>{{$user->first_name}}</td>
                <td>{{$user->last_name}}</td>
                <td>{{$user->email}}</td>
                <td>{{$user->role->role}}</td>
                <td>
                    <form action="{{route('user.edit', ['id' => $user->id])}}" method="post">
                        @csrf
                        <button type="submit" class="btn btn-info">Edit</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
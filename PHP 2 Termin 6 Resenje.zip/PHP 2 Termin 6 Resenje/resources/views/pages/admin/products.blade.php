@extends('layouts.layout')

@section('title') Product - admin panel @endsection
@section('description') All products @endsection
@section('keywords') Products @endsection

@section('content')
<div class="container my-5">
    <h2 class="text-center my-5">Admin panel - products</h2>
    @if(Session::get('success'))
        <p class="alert alert-success">{{Session::get('success')}}</p>
    @endif
    @if(Session::get('error'))
        <p class="alert alert-danger">{{Session::get('success')}}</p>
    @endif
    <table class="table">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Price</th>
                <th scope="col">Currency</th>
                <th scope="col">Categories</th>
                <th scope="col">Supplier</th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
            @foreach ($products as $product)
            <tr>
                <td>{{$product->id}}</td>
                <td>{{$product->name}}</td>
                <td>{{$product->price}}</td>
                <td>{{$product->currency}}</td>
                <td>
                    @foreach ($product->categories as $category)
                        <p class="my-0">{{$category->name}}</p>
                    @endforeach
                </td>
                <td>{{$product->supplier->name}}</td>
                <td>
                    <form action="{{route('product.delete', ['id' => $product->id])}}" method="post">
                        @csrf
                        @method('delete')
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
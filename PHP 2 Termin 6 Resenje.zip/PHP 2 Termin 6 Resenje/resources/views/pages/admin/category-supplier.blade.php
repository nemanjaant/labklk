@extends('layouts.layout')

@section('title') Category - Supplier @endsection
@section('description') Admin panel for categories and suppliers @endsection
@section('keywords') Categories, Suppliers @endsection

@section('content')
<div class="container my-5">
    <h2 class="text-center my-5">Admin panel - category, supplier</h2>
    @if(Session::get('success'))
    <p class="alert alert-success">{{Session::get('success')}}</p>
    @endif
    @if(Session::get('error'))
    <p class="alert alert-danger">{{Session::get('error')}}</p>
    @endif

    <h6>Add new category or supplier</h6>
    <form action="{{route('category-supplier-insert')}}" method="post">
        @csrf
        <div class="form-check">
            <input class="form-check-input" type="radio" name="type" value="category">
            <label class="form-check-label">
                Category
            </label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="type" value="supplier">
            <label class="form-check-label">
                Supplier
            </label>
            @error('type')
            <p class="text-danger">{{$message}}</p>
            @enderror
        </div>
        <div class="mb-3">
            <label class="form-label">Name</label>
            <input type="text" class="form-control" name="name" />
            @error('name')
            <p class="text-danger">{{$message}}</p>
            @enderror
        </div>
        <button type="submit" class="btn btn-success">Add</button>
    </form>
    <br /><br />

    <div id="categories">
        <h4 class="text-center">Categories</h4>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Products</th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody>
                @foreach ($categories as $category)
                <tr>
                    <td>{{$category->id}}</td>
                    <td>{{$category->name}}</td>
                    <td>
                        @if(count($category->products))
                                @foreach ($category->products as $p)
                                    <p class="m-0">ID: {{$p->id}} Name: {{$p->name}}</p>
                                @endforeach
                        @else
                                <p class="m-0">No products for this category.</p>
                        @endif
                    </td>
                    <td>
                        <form action="{{route('category-delete', ['id' => $category->id])}}" method="post">
                            @csrf
                            @method('delete')
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>


    <div id="suppliers" class="my-5">
        <h4 class="text-center mt-5">Suppliers</h4>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Products</th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody>
                @foreach ($suppliers as $supplier)
                <tr>
                    <td>{{$supplier->id}}</td>
                    <td>{{$supplier->name}}</td>
                    <td>
                        @if(count($supplier->products))
                            @foreach ($supplier->products as $p)
                                <p class="m-0">ID: {{$p->id}} Name: {{$p->name}}</p>
                            @endforeach
                        @else
                            <p class="m-0">No products for this supplier.</p>
                        @endif
                    </td>
                    <td>
                        <form action="{{route('supplier-delete', ['id' => $supplier->id])}}" method="post">
                            @csrf
                            @method('delete')
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
window.onload = () => {

    const displayProducts = (data) => {
        document.getElementById('products').innerHTML = data.map(el => {
            return `<div class="col-lg-4 col-md-6 mb-4">
                        <div class="card h-100">
                        <a href="${baseUrl + '/products/' + el.id}"><img class="card-img-top" src="${baseUrl + '/assets/img/products/' + el.image}" alt="${el.name}"></a>
                        <div class="card-body">
                            <h4 class="card-title">
                            <a href="${baseUrl + '/products/' + el.id}">${el.name}</a>
                            </h4>
                            <h5>$${el.price}</h5>
                            <span>${el.categories.map((cat, ind, arr) => arr.length - 1 == ind ? cat.name : `${cat.name}, `).join('')}</span>
                            <p class="card-text mt-3">${el.description}</p>
                        </div>
                        </div>
                    </div>`
        }).join('');
    }

    fetch(baseUrl + '/all-products', {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
          }
    }).then(response => response.json()).then(
        json => {
            displayProducts(json)
        }
    )

}
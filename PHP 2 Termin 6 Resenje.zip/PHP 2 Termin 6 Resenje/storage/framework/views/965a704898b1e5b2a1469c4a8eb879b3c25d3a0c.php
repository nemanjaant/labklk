<footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Shop 2021</p>
    </div>
</footer><?php /**PATH D:\Users\dimitrije\Downloads\PHP 2 Termin 6 Pocetak\resources\views/fixed/footer.blade.php ENDPATH**/ ?>
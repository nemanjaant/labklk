<div class="col-lg-<?php echo e($largeSize); ?> col-md-<?php echo e($mediumSize); ?> mb-4">
    <div class="card h-100">
      <a href="<?php echo e($url); ?>"><img class="card-img-top" src="<?php echo e(asset('assets/img/' . $image)); ?>" alt="<?php echo e($alt); ?>"></a>
      <div class="card-body">
        <h4 class="card-title">
          <a href="<?php echo e($url); ?>"><?php echo e($title); ?></a>
        </h4>
        <h5><?php echo e($subtitle); ?></h5>
        <?php if(!empty($body)): ?>
        <p class="card-text"><?php echo e($body); ?></p>
        <?php endif; ?>
      </div>
    </div>
  </div><?php /**PATH C:\Users\dimitrije.borcanin\Downloads\PHP 2 Termin 7 Resenje\resources\views/components/card.blade.php ENDPATH**/ ?>
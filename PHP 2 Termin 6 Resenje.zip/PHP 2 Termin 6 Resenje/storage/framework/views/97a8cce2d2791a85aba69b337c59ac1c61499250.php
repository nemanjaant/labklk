<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>" />
    <meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>" />
  
    <title>Shop - <?php echo $__env->yieldContent('title'); ?></title>
  
    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" />
  
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" />
  
</head><?php /**PATH C:\Users\dimitrije.borcanin\Downloads\PHP 2 Termin 5 Pocetak\resources\views/fixed/head.blade.php ENDPATH**/ ?>
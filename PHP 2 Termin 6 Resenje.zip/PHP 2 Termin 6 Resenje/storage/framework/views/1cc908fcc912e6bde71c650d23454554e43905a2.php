<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#"><h1 class="h3">Shop</h1></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item <?php if(request()->routeIs('home')): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
              </li>
              <li class="nav-item <?php if(request()->routeIs('products')): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('products')); ?>">Products</a>
              </li>
              <li class="nav-item <?php if(request()->routeIs('contact')): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact</a>
              </li>
        </ul>
      </div>
    </div>
  </nav><?php /**PATH D:\Users\dimitrije\Documents\Projects\php2\shop\resources\views/partials/navigation.blade.php ENDPATH**/ ?>
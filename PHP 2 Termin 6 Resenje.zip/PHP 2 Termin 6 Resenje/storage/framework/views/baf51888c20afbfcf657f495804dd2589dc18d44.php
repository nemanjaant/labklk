

<?php $__env->startSection('title'); ?> Products <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?> Browse all of our products. <?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?> shop, online, products <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4 min-vh-100">

     <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['image' => $product->image,'alt' => $product->name,'title' => $product->name,'subtitle' => '$' . $product->price,'body' => $product->description,'largeSize' => '12','mediumSize' => '12']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\dimitrije\Desktop\ict\php2\t5\vezbe5\resources\views/pages/products/show.blade.php ENDPATH**/ ?>
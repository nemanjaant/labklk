<nav aria-label="Page navigation">
    <ul class="pagination d-flex justify-content-center">
        
    </ul>
</nav>
<?php /**PATH D:\Users\dimitrije\Documents\Projects\php2\shop\resources\views/partials/pagination.blade.php ENDPATH**/ ?>
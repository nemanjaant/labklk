<?php if(session()->has('success')): ?>
<div class="container mt-4">
    <div class="alert alert-success" role="alert">
        <?php echo e(session('success')); ?>

    </div>
</div>
<?php endif; ?><?php /**PATH D:\Users\dimitrije\Documents\Projects\php2\shop\resources\views/partials/success-message.blade.php ENDPATH**/ ?>
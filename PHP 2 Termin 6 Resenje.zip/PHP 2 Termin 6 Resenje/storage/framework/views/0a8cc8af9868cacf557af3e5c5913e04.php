

<?php $__env->startSection('title'); ?> Add product <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?> Add a product. <?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?> shop, online, products <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4 min-vh-100">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </ul>
    </div>
    <?php endif; ?>

    <?php if(session('success-msg')): ?>
    <div class="alert alert-success">
        <p><?php echo e(session('success-msg')); ?></p>
    </div>
    <?php endif; ?>

    <?php if(session('error-msg')): ?>
    <div class="alert alert-danger">
        <p><?php echo e(session('error-msg')); ?></p>
    </div>
    <?php endif; ?>
     
    <form action="<?php echo e(route('products.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Name</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>" />
        </div>
        <div class="mb-3">
            <label for="price" class="form-label">Price</label>
            <input type="text" class="form-control" id="price" name="price" value="<?php echo e(old('price')); ?>" />
        </div>
		<div class="mb-3">
            <label for="currency" class="form-label">Currency</label>
            <select id="currency" class="form-control" name="currency">
				<option value="0">Choose...</option>
				<option value="RSD" <?php if(old('currency') == 'RSD'): ?> selected <?php endif; ?>>RSD</option>
				<option value="EUR" <?php if(old('currency') == 'EUR'): ?> selected <?php endif; ?>>EUR</option>
			</select>
        </div>
        <div class="mb-3">
            <label for="currency" class="form-label">Supplier</label>
            <select id="currency" class="form-control" name="currency">
				<option value="0">Choose...</option>
				<?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea id="description" cols="30" rows="10" class="form-control" name="description"><?php echo e(old('description')); ?></textarea>
        </div>
		<div class="mb-3 row">
            <div class="col-md-2">
                <input type="radio" id="rb-active" value="1" name="active" <?php if(old('active') == 1): ?> checked <?php endif; ?> />
                <label for="rb-active">Active</label>
            </div>
			<div class="col-md-2">
                <input type="radio" id="rb-inactive" value="0" name="active" <?php if(old('active') == 0): ?> checked <?php endif; ?> />
                <label for="rb-inactive">Inactive</label>
            </div>
        </div>
        <div class="mb-3 row">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <input type="checkbox" id="cat-<?php echo e($category->id); ?>" value="<?php echo e($category->id); ?>" name="categories[]" 
                    <?php if(old('categories') && in_array($category->id, old('categories'))): ?> checked <?php endif; ?> />
                <label for="cat-<?php echo e($category->id); ?>"><?php echo e($category->name); ?></label>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
		<div class="mb-3">
            <label for="image" class="form-label">Image</label>
            <input type="file" id="image" name="image"/>
        </div>
        <div>
            <button type="submit" class="btn btn-primary">Add</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Korisnik\Desktop\PHP 2 Termin 5 Resenje\PHP 2 Termin 5 Resenje\resources\views/pages/products/create.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title'); ?> Product - admin panel <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?> All products <?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?> Products <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <h2 class="text-center my-5">Admin panel - products</h2>
    <?php if(Session::get('success')): ?>
        <p class="alert alert-success"><?php echo e(Session::get('success')); ?></p>
    <?php endif; ?>
    <?php if(Session::get('error')): ?>
        <p class="alert alert-danger"><?php echo e(Session::get('success')); ?></p>
    <?php endif; ?>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Price</th>
                <th scope="col">Currency</th>
                <th scope="col">Categories</th>
                <th scope="col">Supplier</th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->id); ?></td>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->price); ?></td>
                <td><?php echo e($product->currency); ?></td>
                <td>
                    <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="my-0"><?php echo e($category->name); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td><?php echo e($product->supplier->name); ?></td>
                <td>
                    <form action="<?php echo e(route('product.delete', ['id' => $product->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Korisnik\Desktop\PHP 2 Termin 6 Resenje\resources\views/pages/admin/products.blade.php ENDPATH**/ ?>
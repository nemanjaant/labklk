

<?php $__env->startSection('title'); ?> Home <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?> Create new product. <?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?> shop, online, create <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mb-3 min-vh-100">
    <div class="card mt-4">
        <div class="card-body">
            <h3 class="card-title">Add a new product</h3>
            <hr />
            <?php echo $__env->make('pages.products.form', ["action" => "products.store"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\dimitrije\Documents\Projects\php2\shop\resources\views/pages/products/create.blade.php ENDPATH**/ ?>
<div class="col-lg-4 col-md-6 mb-4">
    <div class="card h-100">
      <a href="#"><img class="card-img-top" src="<?php echo e(asset('assets/img/' . $product['image'])); ?>" alt="<?php echo e($product['name']); ?>"></a>
      <div class="card-body">
        <h4 class="card-title">
          <a href="#"><?php echo e($product['name']); ?></a>
        </h4>
        <h5>$<?php echo e($product['price']); ?></h5>
        <?php if($description): ?>
        <p class="card-text"><?php echo e($product['description']); ?></p>
        <?php endif; ?>
      </div>
    </div>
  </div><?php /**PATH D:\Users\dimitrije\Desktop\ict\php2\t5\vezbe5\resources\views/partials/product.blade.php ENDPATH**/ ?>
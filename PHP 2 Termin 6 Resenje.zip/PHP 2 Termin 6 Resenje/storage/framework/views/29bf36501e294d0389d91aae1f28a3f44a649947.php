<footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Shop 2021</p>
    </div>
</footer><?php /**PATH D:\Users\dimitrije\Documents\Projects\php2\shop\resources\views/fixed/footer.blade.php ENDPATH**/ ?>
<script src="<?php echo e(asset('assets/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?><?php /**PATH D:\Users\dimitrije\Downloads\PHP 2 Termin 6 Pocetak\resources\views/fixed/scripts.blade.php ENDPATH**/ ?>
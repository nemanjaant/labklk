

<?php $__env->startSection('title'); ?> <?php echo e($product->name); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?> See more info about this item. <?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?> shop, online, home, best, sellers <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mb-3">
    <div class="card mt-4">
        <img class="card-img-top img-fluid w-50 mx-auto" src="<?php echo e(asset('assets/img/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" />
        <div class="card-body">
            <h3 class="card-title"><?php echo e($product->name); ?></h3>
            <h4>$<?php echo e($product->price); ?></h4>
            <p><?php echo e($product->description); ?></p>
            <div class="row mx-1">
                <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-primary mr-3">Edit</a>
                <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\dimitrije\Documents\Projects\php2\shop\resources\views/pages/products/show.blade.php ENDPATH**/ ?>
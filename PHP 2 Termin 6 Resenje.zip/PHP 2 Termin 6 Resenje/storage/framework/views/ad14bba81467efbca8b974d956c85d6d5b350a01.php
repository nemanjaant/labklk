

<?php $__env->startSection('title'); ?> Edit <?php echo e($product->name); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?> Edit a product. <?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?> shop, online, edit <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mb-3 min-vh-100">
    <div class="card mt-4">
        <div class="card-body">
            <h3 class="card-title">Edit a product</h3>
            <hr />
            <?php echo $__env->make('pages.products.form', ["action" => "products.update"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\dimitrije\Documents\Projects\php2\shop\resources\views/pages/products/edit.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title'); ?> Products <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?> Browse all of our products. <?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?> shop, online, products <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container mt-4 min-vh-100">

    <div class="d-flex justify-content-between align-items-center">
      <h1>Products</h1>
      <?php if(Auth::check() && Auth::user()->role == 2): ?>
        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-secondary">Add a product</a>
      <?php endif; ?>
    </div>
    <hr />

    <div class="row">

      <div class="col-lg-3">

        <ul class="list-group">
          <?php $__currentLoopData = $data["categories"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="list-group-item">
            <input type="checkbox" name="categories" id="<?php echo e($categories->id); ?>" /> <?php echo e($categories->name); ?>

          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

      </div>
      <!-- /.col-lg-3 -->

      <div class="col-lg-9">

        <div class="row" id="products">
          
        </div>
        <!-- /.row -->

      </div>
      <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

    
    <!-- /.row -->

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script>
    const baseUrl = "<?php echo e(url('/')); ?>"
  </script>
  <script src="<?php echo e(asset('assets/js/products.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Korisnik\Desktop\PHP 2 Termin 5 Resenje\resources\views/pages/products/index.blade.php ENDPATH**/ ?>
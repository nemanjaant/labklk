

<?php $__env->startSection('title'); ?> Login <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?> Log in into your account. <?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?> shop, online, products <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4 min-vh-100">

    <?php if(session('error-msg')): ?>
    <div class="alert alert-danger">
        <p><?php echo e(session('error-msg')); ?></p>
    </div>
    <?php endif; ?>
     
    <form action="<?php echo e(route('login')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" />
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" />
        </div>
        <div>
            <button type="submit" class="btn btn-primary">Login</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Korisnik\Desktop\PHP 2 Termin 5 Resenje\resources\views/pages/auth/login.blade.php ENDPATH**/ ?>
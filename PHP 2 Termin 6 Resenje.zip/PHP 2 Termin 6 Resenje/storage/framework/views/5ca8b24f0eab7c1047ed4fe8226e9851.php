<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  <div class="container">
    <a class="navbar-brand" href="#">
      <h1 class="h3">Shop</h1>
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav ml-auto">
        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-item <?php if(request()->routeIs($link->route)): ?> active <?php endif; ?>">
          <a class="nav-link" href="<?php echo e(route($link->route)); ?>"><?php echo e($link->name); ?></a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(!Auth::check()): ?>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('loginForm')); ?>">Log in</a>
        </li>
        <?php else: ?>
        <li class="nav-item">
          <form action="<?php echo e(route('logout')); ?>" method="POST" id="logoutForm">
            <?php echo csrf_field(); ?>
            <a class="nav-link" href="#" onclick="event.preventDefault(); document.getElementById('logoutForm').submit();">
              <?php echo e(Auth::user()->name); ?> (Log out)
            </a>
          </form>
        </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
  <?php if(Auth::check() && Auth::user()->role_id === 2): ?>
  <ul class="navbar-nav ml-auto">
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.products')); ?>"> Products</a></li>
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('category-supplier')); ?>"> Categories-Suppliers</a></li>
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('users')); ?>">Users</a></li>
  </ul>
  <?php endif; ?>
</nav><?php /**PATH C:\Users\Korisnik\Desktop\PHP 2 Termin 6 Resenje\resources\views/fixed/navigation.blade.php ENDPATH**/ ?>
<footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Shop 2021</p>
    </div>
</footer><?php /**PATH C:\Users\Korisnik\Desktop\PHP 2 Termin 5 Resenje\resources\views/fixed/footer.blade.php ENDPATH**/ ?>
<?php if(session()->has('errorMessage')): ?>
<div class="container mt-4">
    <div class="alert alert-danger" role="alert">
        <?php echo e(session('errorMessage')); ?>

    </div>
</div>
<?php endif; ?><?php /**PATH D:\Users\dimitrije\Documents\Projects\php2\shop\resources\views/partials/error-message.blade.php ENDPATH**/ ?>
<script src="<?php echo e(asset('assets/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?><?php /**PATH C:\Users\Korisnik\Desktop\PHP 2 Termin 5 Resenje\PHP 2 Termin 5 Resenje\resources\views/fixed/scripts.blade.php ENDPATH**/ ?>
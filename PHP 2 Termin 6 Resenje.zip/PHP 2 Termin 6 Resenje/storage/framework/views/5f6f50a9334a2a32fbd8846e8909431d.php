<div class="col-lg-<?php echo e($largeSize); ?> col-md-<?php echo e($mediumSize); ?> mb-4">
    <div class="card h-100">
      <a href="<?php echo e($url); ?>"><img class="card-img-top" src="<?php echo e(asset('assets/img/' . $image)); ?>" alt="<?php echo e($alt); ?>"></a>
      <div class="card-body">
        <h4 class="card-title">
          <a href="<?php echo e($url); ?>"><?php echo e($title); ?></a>
        </h4>
        <h5><?php echo e($subtitle); ?></h5>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ind => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <span><?php echo e(count($categories) - 1 == $ind ? $c->name : $c->name.', '); ?></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(!empty($body)): ?>
        <p class="card-text mt-3"><?php echo e($body); ?></p>
        <?php endif; ?>
      </div>
    </div>
  </div><?php /**PATH C:\Users\Korisnik\Desktop\PHP 2 Termin 5 Resenje\resources\views/components/card.blade.php ENDPATH**/ ?>
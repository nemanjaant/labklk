<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Faker;
use Illuminate\Support\Facades\DB;

class HomeController extends OsnovniController
{
    public function index(){
        $this->data['products'] = Product::with('categories')->get(); 
        //eager loading - samo jedan poziv ka bazi koji nam vraca sve proizvode sa njegovim kategorijama

        // foreach($this->data['products'] as $p){
        //     $p->categories;
        // }
        // dd($this->data['products']); 
        // lazy loading - jedan poziv da dohvatimo sve podatke za proizvode, a zatim prolaskom kroz petlju i pristupanjem categories dinamickom svojstvu (definisanom metodu u modelu Product) pravimo poziv ka bazi za svaki element kroz koji iteriramo (n+1 problem)

        return view('pages.main.home', ["data" => $this->data]);
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\Supplier;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CategorySupplierController extends Controller
{
    public function getCategoriesSuppliers()
    {
        $categories = Category::with('products')->get();
        $suppliers = Supplier::with('products')->get();
        return view('pages.admin.category-supplier', ['categories' => $categories, 'suppliers' => $suppliers]);
    }

    public function insertCategoriesSuppliers(Request $request)
    {
        $request->validate([
            'type' => 'required|in:category,supplier',
            'name' => 'required|min:3'
        ]);
        try {
            if ($request->type == 'category') {
                $newCategory = new Category();
                $newCategory->name = $request->name;
                $newCategory->save();
            }

            if ($request->type == 'supplier') {
                $newSupplier = new Supplier();
                $newSupplier->name = $request->name;
                $newSupplier->save();
            }

            return redirect()->back()->with('success', 'Successfully added new ' . $request->type);
        } catch (Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    public function deleteCategories($id)
    {
        try {
            DB::beginTransaction();
            $category = Category::find($id);
            $productsIDs = $category->products()->pluck('product_id');
            $products = Product::whereIn('id', $productsIDs)->get();

            foreach ($products as $p) {
                $p->categories()->detach();
            }
            Product::destroy($productsIDs);
            $category->delete();

            DB::commit();

            $message = count($products) == 1 ? "1 product" : count($products) . ' related products';
            return redirect()->back()->with('success', "Category deleted successfully along with $message");
        } catch (Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    public function deleteSuppliers($id)
    {
        try {
            DB::beginTransaction();
            $relatedProducts = Product::where('supplier_id', $id)->get();

            foreach ($relatedProducts as $rp) {
                $rp->categories()->detach();
            }
            Product::destroy($relatedProducts->pluck('id'));
            Supplier::destroy($id);

            DB::commit();
            $message = count($relatedProducts) === 1 ? "1 product" : count($relatedProducts) . " products";
            return redirect()->back()->with('success', "Supplier deleted successfully along with $message");
        } catch (Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}

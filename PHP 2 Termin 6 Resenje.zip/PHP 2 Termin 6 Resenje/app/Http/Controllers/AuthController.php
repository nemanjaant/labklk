<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function loginForm()
    {
        return view('pages.auth.login');
    }

    public function doLogin(Request $request)
    {
        $email = $request->email;
        $password = $request->password;

        $user = User::where('email', $email)->first();
        if (!$user) {
            return redirect()->back()->with('error-msg', 'No user found!');
        }
        if (!Hash::check($password, $user->password)) {
            return redirect()->back()->with('error-msg', 'Wrong password!');
        }
        Auth::login($user);
        return redirect()->route('home');
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->back();
    }

    public function showUsers()
    {
        $users = User::with('role')->get();
        return view('pages.admin.users', ['users' => $users]);
    }

    public function editUser($id)
    {
        $user = User::with('role')->find($id);
        $roles = Role::all();
        return view('pages.admin.edit-users', ['user' => $user, 'roles' => $roles]);
    }

    public function updateUser(Request $request, $id)
    {
        $request->validate([
            'firstName' => 'required|min:3',
            'lastName' => 'required|min:3',
            'email' => 'required|email|unique:users,email,'.User::find($id)->id,
            'role' => 'required|in:1,2'
        ]);
        try {
            $user = User::find($id);

            $user->first_name = $request->firstName;
            $user->last_name = $request->lastName;
            $user->email = $request->email;
            if ($request->password) {
                $user->password = Hash::make($request->password);
            }
            $user->role_id = $request->role;
            $user->save();

            return redirect()->route('users');
        } catch (Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}

<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProductStoreRequest;
use App\Models\Category;
use App\Models\Product;
use App\Models\Supplier;
use Exception;
use Illuminate\Http\Request;
use Faker;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class ProductController extends OsnovniController
{
    public function index()
    {

        $this->data["categories"] = Category::all();

        return view('pages.products.index', ["data" => $this->data]);
    }

    public function show($id)
    {

        $product = Product::find($id);

        return view('pages.products.show', ['product' => $product]);
    }

    public function getAll(Request $request)
    {
        if ($request->ajax()) {
            $products = Product::with('categories')->get();
            return response()->json($products);
        } else {
            $products = Product::with(['categories', 'supplier'])->get();
            return view('pages.admin.products', ['products' => $products]);
        }
    }

    public function create()
    {
        $categories = Category::all();
        $suppliers = Supplier::all();
        return view('pages.products.create', ["categories" => $categories, "suppliers" => $suppliers]);
    }

    public function store(ProductStoreRequest $request)
    {
        $data = $request->only('name', 'price', 'currency', 'description', 'active');
        $imageName = time() . '.' . $request->image->extension();
        try {
            DB::beginTransaction();
            $request->image->move(public_path('assets/img/products'), $imageName);
            $newProduct = Product::create($data + ["image" => $imageName]);
            $newProduct->categories()->sync($request->categories);
            DB::commit();
            return redirect()->route('products');
        } catch (Exception $e) {
            DB::rollBack();
            if (File::exists(public_path('/assets/img/products/' . $imageName))) {
                File::delete(public_path('/assets/img/products/' . $imageName));
            }
            return redirect()->back()->with('error-msg', $e->getMessage());
        }
        return back()->with('success-msg', "Successfully added a product!");
    }

    public function delete($id)
    {
        try {
            DB::beginTransaction();
            $product = Product::find($id);
            $product->categories()->detach();
            $product->delete();
            DB::commit();
            return redirect()->back()->with('success', 'Product deleted successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}

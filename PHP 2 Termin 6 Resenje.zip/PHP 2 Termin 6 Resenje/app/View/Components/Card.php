<?php

namespace App\View\Components;

use Illuminate\View\Component;

class Card extends Component
{
    public $image;
    public $alt;
    public $title;
    public $subtitle;
    public $body;
    public $largeSize;
    public $mediumSize;
    public $url;
    public $categories;
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($image, $alt, $title, $subtitle, $categories, $body = '', $largeSize = 4, $mediumSize = 6, $url = '#')
    {
        $this->image = $image;
        $this->alt = $alt;
        $this->title = $title;
        $this->subtitle = $subtitle;
        $this->body = $body;
        $this->largeSize = $largeSize;
        $this->mediumSize = $mediumSize;
        $this->url = $url;
        $this->categories = $categories;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|string
     */
    public function render()
    {
        return view('components.card');
    }
}
